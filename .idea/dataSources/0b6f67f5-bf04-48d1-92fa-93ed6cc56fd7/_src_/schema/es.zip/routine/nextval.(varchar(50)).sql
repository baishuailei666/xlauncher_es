CREATE FUNCTION nextval(n VARCHAR(50))
  RETURNS INT
  begin 
declare _cur int;
set _cur=(select current_value from sequence where name= n);
update sequence
set current_value = _cur + _increment
where name=n ;
return _cur;
end;
